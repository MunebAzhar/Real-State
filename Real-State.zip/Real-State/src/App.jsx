import React from "react";
import NavBar from "./Components/NavBar/NavBar.jsx";
import Home from "./Components/Home/Home";
import Mission from "./Components/Mission/Mission";
import Choose from "./Components/Choose/Choose.jsx";
import House from "./Components/Featured/House/House";
import Office from "./Components/Featured/Office/Office";
import Land from "./Components/Featured/Land/Land";
import Discover from "./Components/Discover/Discover";
import Footer from "./Components/Footer/Footer";

function App() {
  return (
    <>
      <NavBar />
      <Home />
      <Mission />
      <Choose />
      <House />
      <Office />
      <Land />
      <Discover />
      <Footer />
    </>
  );
}

export default App;
