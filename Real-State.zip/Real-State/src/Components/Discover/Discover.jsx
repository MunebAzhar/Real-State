import React from 'react';
import './Discover.css';

export default function Discover() {
  return (
    <>
    <div className="discover--main">
        <div className="txt">Discover a home you'll love to stay</div>
    </div>
    </>
  )
}
