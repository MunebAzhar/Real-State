import React from "react";
import "./Choose.css";
import { ImHourGlass } from "react-icons/im";
import { RiFolderUserLine } from "react-icons/ri";
import { TbBrandOffice } from "react-icons/tb";
import { TbBuildingWarehouse } from "react-icons/tb";
import { TbCommand } from "react-icons/tb";
import { BsClipboardData } from "react-icons/bs";

export default function Choose() {
  const chooseData = [
    {
      icon: <ImHourGlass size={30} color="whitesmoke" />,
      title: "In Business Since 1932",
      description:
        "Brokers have an average of 20+ years of experience in commerical real estate and help guide clients through the intricacies of the industry.",
    },
    {
      icon: <RiFolderUserLine  size={30} color="whitesmoke" />,
      title: "Repeat Clients + Referrals",
      description:
        "The company is committed to success and builds its reputation one client at at time.",
    },
    {
      icon: <TbBrandOffice  size={30} color="whitesmoke" />,
      title: "Clients List Multiple Properties",
      description:
        "One of the best acknowledgements of the company’s integrity and experience is the trust from clients who list multiple properties with the firm.",
    },
    {
      icon: <TbBuildingWarehouse  size={30} color="whitesmoke" />,
      title: "Real-Time Updates",
      description:
        "OClients can follow the status of their property in real-time from anywhere in the world with the click of a button.",
    },
    {
      icon: <TbCommand  size={30} color="whitesmoke" />,
      title: "Professionalism",
      description:
        "Brokers are licensed professionals who have studied and trained extensively to achieve the highest certification within the industry.",
    },
    {
      icon: <BsClipboardData size={30} color="whitesmoke"  />,
      title: "Personal Service",
      description:
        "Knowledge, experience and integrity are delivered through personal attention to detail and dedication to client and partner success.",
    },
  ];

  return (
    <>
      <div className="choose--main">
        <div className="heading">Why Choose Us?</div>
        <div className="choose--info">
          {chooseData.map((data, index) => (
            <div className="info--main" key={index}>
              <div className="info--body">
                <div className="icons">{data.icon}</div>
                <span className="title">{data.title}</span>
                <p className="detail">{data.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
