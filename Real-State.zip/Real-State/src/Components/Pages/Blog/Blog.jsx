import React from 'react';
import "./Blog.css";
import NavBar from '../../NavBar/NavBar';


function Blog() {
  return (
    <>
    <NavBar />
    Blog
    </>
  )
}

export default Blog