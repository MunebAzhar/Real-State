import React from 'react';
import "./Contact.css";
import NavBar from '../../NavBar/NavBar';

function Contact() {
  return (
    <>
    <NavBar />
    Contact
    </>
  )
}

export default Contact