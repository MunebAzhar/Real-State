import React from "react";
import "./About.css";
import NavBar from "../../NavBar/NavBar";
import Footer from "../../Footer/Footer";
import boyImage from "../../../assets/Images/team.jpg";
// import bgImg from "../../../assets/Images/blog.jpg";
import { BsMailbox } from "react-icons/bs";
import { BsTwitter } from "react-icons/bs";
import { AiFillLinkedin } from "react-icons/ai";
import { AiOutlinePhone } from "react-icons/ai";

export default function About() {
  const aboutData = [
    {
      title: "Residential Sales",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Commercial Property",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Property Management",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Investment Consultation",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Mortgage Services",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Land Development",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Luxury Homes",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Relocation Services",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
    {
      title: "Rental Properties",
      description:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborumnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem.",
    },
  ];

  const teamData = [
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },{
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },{
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
    {
      image: boyImage,
      name: "Kenneth F. Crimmins",
      position1: "CCIM, SIOR",
      position2: "President | Broker of Record | Principal",
      mail: <BsMailbox color="rgb(192, 53, 58)" />,
      phone: <AiOutlinePhone color="rgb(192, 53, 58)" />,
      twitter: <BsTwitter color="rgb(192, 53, 58)" />,
      linkedin: <AiFillLinkedin color="rgb(192, 53, 58)" />,
      bio: "Full bio",
    },
  ];

  return (
    <>
      <NavBar />
      {/* <div className="about--bg--img">
        <img src={bgImg} alt="" />
      </div> */}

      {/* <-----Section1----------> */}

      <div className="about--main">
        <div className="heading">Our Expertise</div>
        <div className="mission--cards">
          {aboutData.map((data, index) => (
            <div className="aboutcards--main" key={index}>
              <div className="cards--body">
                <span className="title">{data.title}</span>
                <p className="detail">{data.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* <-----Section2----------> */}

      <div className="team--main">
        <div className="heading">Meet Our Team</div>
      </div>
      <div className="team--cards">
        {teamData.map((data, index) => (
          <div className="team--detail" key={index}>
            <div className="team--body">
              <div className="team--img">
                <img src={data.image} alt="" className="team--img" />
              </div>
              <div className="team--details">
                <div className="name">{data.name}</div>
                <div className="position1">{data.position1}</div>
                <div className="position2">{data.position2}</div>
                <div className="mail">{data.mail} John@gmail.com </div> 
                <div className="phone">{data.phone} +111 5254 5545</div>
                <div className="twitter">{data.twitter} Jason M. Crimmins </div>
                <div className="linkedin">{data.linkedin} Jason M. Crimmins </div>
                <div className="button--container">
                <button className="bio">{data.bio}</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <Footer />
    </>
  );
}
