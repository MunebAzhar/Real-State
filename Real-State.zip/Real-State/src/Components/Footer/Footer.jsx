import React from "react";
import "./Footer.css";
import {AiOutlineCopyright} from "react-icons/ai";

export default function Footer() {
  return (
    <>
      <div className="footer--main">
        <div className="footer--logo">
            REAL-$TATE
            </div>

        <div className="page--links">
          <span>LINKS</span>
          <ul>
            <li>About</li>
            <li>Services</li>
            <li>properties</li>
            <li>Blog</li>
            <li>News</li>
            <li>Contact</li>
          </ul>
        </div>

        <div className="social--links">
          <span>FOLLOW</span>
          <ul>
            <li>Twitter</li>
            <li>Facebook</li>
            <li>Linkedin</li>
            <li>Instagram</li>
          </ul>
        </div>

        <div className="subscription">
          <span>SUBSCRIBE TO OUR NEWSLETTER</span>
          <div className="newsletter">
            <input type="search" placeholder="Email" />
            <button>OK</button>
          </div>
        </div>

        <div className="copyright">
            COPYRIGHT <AiOutlineCopyright /> 2023 INTELLECT DIVE
        </div>
      </div>
    </>
  );
}
