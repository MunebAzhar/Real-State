import React from "react";
import houseImage from "../../../assets/Images/Houses.jpg";
import { BsHouseHeartFill } from "react-icons/bs";
import "./House.css";

export default function House() {
  const houseData = [
    {
      image: houseImage,
      title: "House For Sale",
      Location: "New York",
      detail1: "Bedroom: 4",
      detail2: "Size: 500 m2",
      icon: <BsHouseHeartFill size={20} /> ,
      detail3: "Status: Available"
    },
    {
      image: houseImage,
      title: "House For Sale",
      Location: "California",
      detail1: "Bedroom: 4",
      detail2: "Size: 500 m2",
      icon: <BsHouseHeartFill size={20}/> ,
      detail3: "Status: Available"
    },
    {
      image: houseImage,
      title: "House For Sale",
      Location: "Florida",
      detail1: "Bedroom: 4",
      detail2: "Size: 500 m2",
      icon: <BsHouseHeartFill size={20}/> ,
      detail3: "Status: Available"
    },
  ];

  return (
    <>
      <div className="house--main">

        <div className="headings">
          <span>Featured</span> <br />
          <h2>Houses</h2>
        </div>

        <div className="house--cards">
          {houseData.map((data, index) => (
            <div className="house--detail" key={index}>
              <div className="detail--body">
                <img src={data.image} alt=""  className="card--img"/>
                <div className="title">{data.title}</div>
                <div className="location">{data.Location}</div>
                <div className="detail1">{data.detail1}</div>
                <div className="detail2">{data.detail2}</div>
                <hr />
                <div className="status">
                <div className="like--icon">{data.icon}</div>
                <div className="detail3">{data.detail3}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
