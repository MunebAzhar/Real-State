import React from "react";
import officeImage from "../../../assets/Images/Office.jpg";
import { BsHouseHeartFill } from "react-icons/bs";
import "./Office.css";

export default function Office() {
  const houseData = [
    {
      image: officeImage,
      title: "Office For Sale",
      Location: "New York",
      detail1: "Room: 5",
      detail2: "Size: 400 m3",
      icon: <BsHouseHeartFill size={20} /> ,
      detail3: "Status: Available"
    },
    {
      image: officeImage,
      title: "Office For Sale",
      Location: "California",
      detail1: "Room: 5",
      detail2: "Size: 400 m3",
      icon: <BsHouseHeartFill size={20}/> ,
      detail3: "Status: Available"
    },
    {
      image: officeImage,
      title: "Office For Sale",
      Location: "Florida",
      detail1: "Room: 5",
      detail2: "Size: 400 m3",
      icon: <BsHouseHeartFill size={20}/> ,
      detail3: "Status: Available"
    },
  ];

  return (
    <>
      <div className="house--main">

        <div className="headings">
          <span>Featured</span> <br />
          <h2>Offices</h2>
        </div>

        <div className="house--cards">
          {houseData.map((data, index) => (
            <div className="house--detail" key={index}>
              <div className="detail--body">
                <img src={data.image} alt=""  className="card--img"/>
                <div className="title">{data.title}</div>
                <div className="location">{data.Location}</div>
                <div className="detail1">{data.detail1}</div>
                <div className="detail2">{data.detail2}</div>
                <hr />
                <div className="status">
                <div className="like--icon">{data.icon}</div>
                <div className="detail3">{data.detail3}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
