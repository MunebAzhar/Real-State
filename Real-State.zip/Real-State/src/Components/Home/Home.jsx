import React from "react";
import "./Home.css";
import homeVideo from "../../assets/homeVideo.mp4";

export default function Home() {
  return (
    <>
      <div className="home--main">
        <div className="video--container">
          <video
            src={homeVideo}
            type="video/mp4"
            // controls
            preload="auto"
            autoPlay
            muted
            loop
            playsInline
          ></video>
        </div>
        <div className="home--txt">
          <div className="heading">Corporate Real State Solutions</div>
          <div className="detail">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime
            mollitia, molestiae quas vel sint commodi repudiandae consequuntur
            voluptatum laborum numquam blanditiis harum quisquam eius sed odit
            fugiat iusto fuga praesentium optio, eaque rerum! Provident
            similique accusantium nemo autem. Veritatis obcaecati tenetur iure
            eius earum ut molestias architecto voluptate aliquam nihil, eveniet
            aliquid culpa officia aut! Impedit sit sunt quaerat, odit, tenetur
            error, harum nesciunt ipsum debitis quas aliquid.
          </div>
        </div>
      </div>
    </>
  );
}
