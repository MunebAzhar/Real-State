import React from "react";
import "./Mission.css";

export default function Mission() {
  const missionData = [
    {
      title: "EXPERT MARKET SERVICES",
      description:
        "Our commercial real estate brokers know their markets and successfully guide our clients through the process of purchasing, selling, leasing, customizing and expanding their assets.",
    },
    {
      title: "DEDICATED SERVICE",
      description:
        "The tradition of personal service began in 1932. Knowledge, experience and personal attention are provided to our clients by our dedicated team of commercial real estate professionals. A true testament to the Company is our significant growth through referrals and repeat customers.",
    },
    {
      title: "CLIENT SUCCESS",
      description:
        "We are a network of professionals committed to our clients' success, and have built our reputation one client at a time. Combining local expertise, cutting edge technology and global reach through networking and affiliates, The Company creates a winning combination for our clients and partners.",
    },
    {
      title: "TRUST & INTEGRITY",
      description:
        "We are a company built on trust, a team driven by integrity.",
    },
    {
      title: "QUALITY",
      description:
        "We deliver only excellence and aim to exceed expectations in everything we do.",
    },
    {
      title: "COURAGE",
      description:
        "We make decisions and act in the best interests of our clients, even in the face of personal or professional adversity.",
    },
  ];
  return (
    <>
      <div className="mission--main">
        <div className="heading">Our Mission</div>
        <div className="mission--cards">
          {missionData.map((data, index) => (
            <div className="cards--main" key={index}>
              <div className="cards--body">
                <span className="title">{data.title}</span>
                <p className="detail">{data.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
